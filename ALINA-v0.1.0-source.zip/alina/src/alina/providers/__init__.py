"""Analysis provider adapters."""
